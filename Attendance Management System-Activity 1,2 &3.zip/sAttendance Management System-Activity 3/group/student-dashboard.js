const user = JSON.parse(localStorage.getItem('loggedInUser'));
if (!user) window.location.href = 'index.html';

document.getElementById('welcome').textContent = 
  `Welcome, ${user.name} (${user.role})`;

document.querySelector('.logout-btn').addEventListener('click', () => {
  localStorage.removeItem('loggedInUser');
  window.location.href = 'index.html';
});

// Load available courses
fetch('courses.json')
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById('student-courses');
    list.innerHTML = `
      <table>
        <tr>
          <th>Course</th>
          <th>Code</th>
          <th>Instructor</th>
          <th>Auditors</th>
        </tr>
        ${data.map(c => `
          <tr>
            <td>${c.name}</td>
            <td>${c.code}</td>
            <td>${c.instructor}</td>
            <td>
              <select onchange="joinCourse('${c.code}', this.value)">
                <option value="">Select</option>
                <option value="student">Student</option>
                <option value="auditor">Auditor</option>
              </select>
            </td>
          </tr>
        `).join('')}
      </table>
    `;
  });

