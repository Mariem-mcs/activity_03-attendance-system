// Handle Registration
const registerForm = document.getElementById('register-form');
if (registerForm) {
  registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value.trim();
    const confirm = document.getElementById('reg-confirm-password').value.trim();
    const role = document.querySelector('input[name="role"]:checked')?.value;

    if (password !== confirm) {
      alert('Passwords do not match.');
      return;
    }
    if (!role) {
      alert('Please select a role.');
      return;
    }

    const user = { name, email, password, role };
    localStorage.setItem('user', JSON.stringify(user));
    alert(`Registration successful as ${role}! You can now log in.`);
    window.location.href = 'index.html';
  });
}

// Handle Login
const loginForm = document.getElementById('login-form');
if (loginForm) {
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value.trim();

    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (!storedUser) {
      alert('No user found. Please register first.');
      return;
    }

    if (storedUser.email === email && storedUser.password === password) {
      localStorage.setItem('loggedInUser', JSON.stringify(storedUser));

      if (storedUser.role === 'Faculty Intern') {
        window.location.href = 'faculty-dashboard.html';
      } else {
        window.location.href = 'student-dashboard.html';
      }
    } else {
      alert('Invalid email or password.');
    }
  });
}
