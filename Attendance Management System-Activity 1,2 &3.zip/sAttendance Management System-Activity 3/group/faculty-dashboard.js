const user = JSON.parse(localStorage.getItem('loggedInUser'));
if (!user) window.location.href = 'index.html';

document.getElementById('welcome').textContent = 
  `Welcome, ${user.name} (${user.role})`;

document.querySelector('.logout-btn').addEventListener('click', () => {
  localStorage.removeItem('loggedInUser');
  window.location.href = 'index.html';
});

fetch('courses.json')
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById('course-list');
    list.innerHTML = `
      <table>
        <tr>
          <th>Course</th>
          <th>Code</th>
          <th>Instructor</th>
          <th>Auditors</th>
        </tr>
        ${data.map(c => `
          <tr>
            <td>${c.name}</td>
            <td>${c.code}</td>
            <td>${c.instructor}</td>
            <td>${c.auditors.length ? c.auditors.join(', ') : 'None'}</td>
          </tr>
        `).join('')}
      </table>
    `;
  });
