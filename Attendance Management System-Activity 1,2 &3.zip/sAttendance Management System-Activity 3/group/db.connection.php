<?php
print("Connected Successfully!!");
$pageColor="#CCC";
?>
<script>
document.body.style.backgroundColor="<?php print($pageColor);?>";
</script>
