<?php
$host = "localhost";           
$username = "root";            
$password = "mariem@sall19052003";      
$database = "Activity-03-mySql"; 
function getDBConnection() {
    global $host, $username, $password, $database;
    
    
    $conn = new mysqli($host, $username, $password, $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}
?>
